//
//  ViewControllerLoginPage.swift
//  Project1_Stiga_App_BDPP_1
//
//  Created by Michele Pepe on 06/02/26.
//

import UIKit

class ViewControllerLoginPage: UIViewController {
    
    
    @IBAction func Accetta(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let identifier = "ViewControllerRC" // Update this if your storyboard ID is different
        
        guard let vcRC = storyboard.instantiateViewController(withIdentifier: identifier) as? ViewControllerRC else {
            assertionFailure("Couldn't instantiate ViewController_ItaIng with identifier '\(identifier)'. Check the Storyboard ID and class.")
            return
        }
        vcRC.modalPresentationStyle = .fullScreen
        self.present(vcRC, animated: true, completion: nil)
        
    }
    
    @IBAction func AccediRegistrati(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let identifier = "ViewControllerEmailPass" // Update this if your storyboard ID is different
        
        guard let vcEP = storyboard.instantiateViewController(withIdentifier: identifier) as? ViewControllerEmailPass else {
            assertionFailure("Couldn't instantiate ViewController_ItaIng with identifier '\(identifier)'. Check the Storyboard ID and class.")
            return
        }
        vcEP.modalPresentationStyle = .fullScreen
        self.present(vcEP, animated: true, completion: nil)
    }
    
    let emailField: UITextField = {
            let field = UITextField()
            field.placeholder = "Inserisci l'email"
            field.borderStyle = .roundedRect
            field.keyboardType = .emailAddress
            field.autocapitalizationType = .none
            field.translatesAutoresizingMaskIntoConstraints = false
            return field
        }()

        

        override func viewDidLoad() {
            super.viewDidLoad()

            view.backgroundColor = .black // se vuoi stile come screenshot

            view.addSubview(emailField)
            

            NSLayoutConstraint.activate([
                emailField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                emailField.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -140),
                emailField.widthAnchor.constraint(equalToConstant: 280),
                emailField.heightAnchor.constraint(equalToConstant: 44)
            ])
        }
}
