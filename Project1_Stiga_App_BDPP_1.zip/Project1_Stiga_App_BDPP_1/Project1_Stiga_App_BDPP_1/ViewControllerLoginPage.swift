//
//  ViewControllerLoginPage.swift
//  Project1_Stiga_App_BDPP_1
//
//  Created by Michele Pepe on 06/02/26.
//

import UIKit

class ViewControllerLoginPage: UIViewController, UITextViewDelegate {

    private let gradientLayer: CAGradientLayer = {
        let g = CAGradientLayer()
        g.colors = [
            UIColor(red: 0.04, green: 0.05, blue: 0.08, alpha: 1).cgColor,
            UIColor(red: 0.06, green: 0.08, blue: 0.12, alpha: 1).cgColor
        ]
        g.startPoint = CGPoint(x: 0.3, y: 0)
        g.endPoint   = CGPoint(x: 0.7, y: 1)
        return g
    }()

    private let cardView: UIView = {
        let v = UIView()
        v.backgroundColor    = UIColor(red: 0.11, green: 0.13, blue: 0.17, alpha: 1)
        v.layer.cornerRadius = 24
        v.layer.borderWidth  = 1
        v.layer.borderColor  = UIColor(white: 1, alpha: 0.08).cgColor
        v.layer.shadowColor   = UIColor.black.cgColor
        v.layer.shadowOpacity = 0.5
        v.layer.shadowOffset  = CGSize(width: 0, height: 8)
        v.layer.shadowRadius  = 24
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let topBadge: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("Accedi o registrati", for: .normal)
        b.setTitleColor(UIColor(white: 0.75, alpha: 1), for: .normal)
        b.titleLabel?.font   = UIFont.systemFont(ofSize: 16, weight: .semibold)
        b.backgroundColor    = UIColor(red: 0.15, green: 0.17, blue: 0.22, alpha: 1)
        b.layer.cornerRadius = 18
        b.layer.borderWidth  = 1
        b.layer.borderColor  = UIColor(white: 1, alpha: 0.10).cgColor
        b.isUserInteractionEnabled = true
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    private let titleLabel: UILabel = {
        let l = UILabel()
        l.text          = "Crea il tuo profilo"
        l.font          = UIFont.systemFont(ofSize: 32, weight: .bold)
        l.textColor     = .white
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private let subtitleLabel: UILabel = {
        let l = UILabel()
        l.text          = "Inserisci l'email che usi su questo telefono per registrarti o accedere nuovamente"
        l.font          = UIFont.systemFont(ofSize: 16, weight: .regular)
        l.textColor     = UIColor(white: 0.50, alpha: 1)
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private let emailContainer: UIView = {
        let v = UIView()
        v.backgroundColor    = UIColor(red: 0.14, green: 0.16, blue: 0.21, alpha: 1)
        v.layer.cornerRadius = 16
        v.layer.borderWidth  = 1
        v.layer.borderColor  = UIColor(white: 1, alpha: 0.10).cgColor
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let emailIconView: UIImageView = {
        let iv = UIImageView()
        iv.image       = UIImage(systemName: "envelope")
        iv.tintColor   = UIColor(white: 0.45, alpha: 1)
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let emailField: UITextField = {
        let f = UITextField()
        f.keyboardType           = .emailAddress
        f.autocapitalizationType = .none
        f.autocorrectionType     = .no
        f.textColor              = .white
        f.tintColor              = UIColor(white: 0.80, alpha: 1)
        f.font                   = UIFont.systemFont(ofSize: 16)
        f.backgroundColor        = .clear
        f.borderStyle            = .none
        f.attributedPlaceholder  = NSAttributedString(
            string: "Indirizzo e-mail",
            attributes: [.foregroundColor: UIColor(white: 0.38, alpha: 1)]
        )
        f.translatesAutoresizingMaskIntoConstraints = false
        return f
    }()

    private let continueButton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("CONTINUA", for: .normal)
        b.setTitleColor(.white, for: .normal)
        b.titleLabel?.font   = UIFont.systemFont(ofSize: 15, weight: .bold)
        b.backgroundColor    = UIColor(red: 0.20, green: 0.22, blue: 0.28, alpha: 1)
        b.layer.cornerRadius = 28
        b.layer.borderWidth  = 1
        b.layer.borderColor  = UIColor(white: 1, alpha: 0.12).cgColor
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    private let spinner: UIActivityIndicatorView = {
        let a = UIActivityIndicatorView(style: .medium)
        a.color = .white
        a.hidesWhenStopped = true
        a.translatesAutoresizingMaskIntoConstraints = false
        return a
    }()

    private let errorLabel: UILabel = {
        let l = UILabel()
        l.font          = UIFont.systemFont(ofSize: 13, weight: .medium)
        l.textColor     = UIColor(red: 0.97, green: 0.40, blue: 0.40, alpha: 1)
        l.numberOfLines = 0
        l.isHidden      = true
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private lazy var legalTextView: UITextView = {
        let tv = UITextView()
        tv.backgroundColor    = .clear
        tv.isEditable         = false
        tv.isScrollEnabled    = false
        tv.textAlignment      = .center
        tv.textContainerInset = .zero
        tv.textContainer.lineFragmentPadding = 0
        tv.translatesAutoresizingMaskIntoConstraints = false

        let base = "Continuando, confermo di aver letto e accettato le Informativa sulla privacy e Contratto di licenza."
        let attr = NSMutableAttributedString(
            string: base,
            attributes: [
                .font: UIFont.systemFont(ofSize: 13),
                .foregroundColor: UIColor(white: 0.42, alpha: 1)
            ]
        )
        if let r = base.range(of: "Informativa sulla privacy") {
            attr.addAttributes([
                .link: "action://privacy",
                .foregroundColor: UIColor(white: 0.85, alpha: 1),
                .underlineStyle: NSUnderlineStyle.single.rawValue
            ], range: NSRange(r, in: base))
        }
        if let r = base.range(of: "Contratto di licenza") {
            attr.addAttributes([
                .link: "action://license",
                .foregroundColor: UIColor(white: 0.85, alpha: 1),
                .underlineStyle: NSUnderlineStyle.single.rawValue
            ], range: NSRange(r, in: base))
        }
        tv.attributedText = attr
        tv.linkTextAttributes = [
            .foregroundColor: UIColor(white: 0.85, alpha: 1),
            .underlineStyle: NSUnderlineStyle.single.rawValue
        ]
        return tv
    }()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupGradient()
        buildLayout()
        wireActions()
        legalTextView.delegate = self
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gradientLayer.frame = view.bounds
    }

    // MARK: - UITextViewDelegate

    func textView(_ textView: UITextView,
                  shouldInteractWith URL: URL,
                  in characterRange: NSRange,
                  interaction: UITextItemInteraction) -> Bool {
        switch URL.absoluteString {
        case "action://privacy": openLegal(.privacy)
        case "action://license": openLegal(.license)
        default: break
        }
        return false
    }

    // MARK: - Setup

    private func setupGradient() {
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    private func buildLayout() {
        emailContainer.addSubview(emailIconView)
        emailContainer.addSubview(emailField)
        view.addSubview(cardView)

        [topBadge, titleLabel, subtitleLabel,
         emailContainer, errorLabel,
         continueButton, spinner,
         legalTextView].forEach { cardView.addSubview($0) }

        let p: CGFloat = 24

        NSLayoutConstraint.activate([
            cardView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            cardView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 32),
            cardView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -32),

            topBadge.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 28),
            topBadge.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            topBadge.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),
            topBadge.heightAnchor.constraint(equalToConstant: 44),

            titleLabel.topAnchor.constraint(equalTo: topBadge.bottomAnchor, constant: 28),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            titleLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),

            subtitleLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
            subtitleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            subtitleLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),

            emailContainer.topAnchor.constraint(equalTo: subtitleLabel.bottomAnchor, constant: 28),
            emailContainer.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            emailContainer.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),
            emailContainer.heightAnchor.constraint(equalToConstant: 58),

            emailIconView.leadingAnchor.constraint(equalTo: emailContainer.leadingAnchor, constant: 16),
            emailIconView.centerYAnchor.constraint(equalTo: emailContainer.centerYAnchor),
            emailIconView.widthAnchor.constraint(equalToConstant: 20),
            emailIconView.heightAnchor.constraint(equalToConstant: 20),

            emailField.leadingAnchor.constraint(equalTo: emailIconView.trailingAnchor, constant: 10),
            emailField.trailingAnchor.constraint(equalTo: emailContainer.trailingAnchor, constant: -16),
            emailField.centerYAnchor.constraint(equalTo: emailContainer.centerYAnchor),

            errorLabel.topAnchor.constraint(equalTo: emailContainer.bottomAnchor, constant: 8),
            errorLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            errorLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),

            continueButton.topAnchor.constraint(equalTo: errorLabel.bottomAnchor, constant: 20),
            continueButton.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            continueButton.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),
            continueButton.heightAnchor.constraint(equalToConstant: 58),

            spinner.centerXAnchor.constraint(equalTo: continueButton.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: continueButton.centerYAnchor),

            legalTextView.topAnchor.constraint(equalTo: continueButton.bottomAnchor, constant: 24),
            legalTextView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            legalTextView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),
            legalTextView.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -28)
        ])
    }

    private func wireActions() {
        topBadge.addTarget(self, action: #selector(badgeTapped), for: .touchUpInside)
        continueButton.addTarget(self, action: #selector(continueTapped), for: .touchUpInside)
        emailField.addTarget(self, action: #selector(clearError), for: .editingChanged)
        emailField.addTarget(self, action: #selector(continueTapped), for: .editingDidEndOnExit)
        emailField.addTarget(self, action: #selector(fieldActive), for: .editingDidBegin)
        emailField.addTarget(self, action: #selector(fieldInactive), for: .editingDidEnd)

        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }

    // MARK: - Actions

    @objc private func badgeTapped() {
        dismissKeyboard()
        navigateToEmailPass(prefillEmail: emailField.text)
    }

    @objc private func continueTapped() {
        dismissKeyboard()
        clearError()
        guard let email = emailField.text, !email.isEmpty else {
            showError("Inserisci il tuo indirizzo email.")
            shake(emailContainer)
            return
        }
        navigateToEmailPass(prefillEmail: email)
    }

    private func openLegal(_ document: LegalDocument) {
        let vc = LegalWebViewController()
        vc.document = document
        vc.modalPresentationStyle = .pageSheet
        if let sheet = vc.sheetPresentationController {
            sheet.detents = [.large()]
            sheet.prefersGrabberVisible = true
        }
        present(vc, animated: true)
    }

    private func navigateToEmailPass(prefillEmail: String?) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        guard let vcEP = sb.instantiateViewController(withIdentifier: "ViewControllerEmailPass") as? ViewControllerEmailPass else {
            assertionFailure("Storyboard ID 'ViewControllerEmailPass' non trovato.")
            return
        }
        vcEP.prefillEmail           = prefillEmail ?? ""
        vcEP.modalPresentationStyle = .fullScreen
        present(vcEP, animated: true)
    }

    @IBAction func Accetta(_ sender: Any)          { continueTapped() }
    @IBAction func AccediRegistrati(_ sender: Any) { badgeTapped() }

    @objc private func dismissKeyboard() { view.endEditing(true) }
    @objc private func clearError()      { errorLabel.isHidden = true }

    @objc private func fieldActive() {
        UIView.animate(withDuration: 0.2) {
            self.emailContainer.layer.borderColor = UIColor(white: 1, alpha: 0.35).cgColor
        }
    }

    @objc private func fieldInactive() {
        UIView.animate(withDuration: 0.2) {
            self.emailContainer.layer.borderColor = UIColor(white: 1, alpha: 0.10).cgColor
        }
    }

    private func showError(_ msg: String) {
        errorLabel.text     = msg
        errorLabel.isHidden = false
    }

    private func shake(_ v: UIView) {
        let anim = CAKeyframeAnimation(keyPath: "transform.translation.x")
        anim.timingFunction = CAMediaTimingFunction(name: .linear)
        anim.duration       = 0.38
        anim.values         = [-8, 8, -5, 5, -3, 3, 0]
        v.layer.add(anim, forKey: "shake")
    }
}
