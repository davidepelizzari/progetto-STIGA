//
//  StigaAPI.swift
//  Project1_Stiga_App_BDPP_1
//
//  Created by Michele Pepe on 24/03/26.
//

import Foundation

private enum Config {
    static let firebaseAPIKey  = "AIzaSyCPtRBU_hwWZYsguHp9ucGrfNac0kXR6ug"
    static let firebaseBaseURL = "https://www.googleapis.com/identitytoolkit/v3/relyingparty"
    static let stigaBaseURL    = "https://connectivity-production.stiga.com"
}

struct StigaDevice {
    let uuid: String
    let name: String
}

enum StigaError: LocalizedError {
    case invalidCredentials
    case tooManyAttempts
    case accountDisabled
    case noDeviceFound
    case httpError(Int)
    case networkError(Error)
    case decodingError

    var errorDescription: String? {
        switch self {
        case .invalidCredentials:  return "Email o password non corretti. Riprova."
        case .tooManyAttempts:     return "Troppi tentativi falliti. Riprova più tardi."
        case .accountDisabled:     return "Account disabilitato. Contatta il supporto."
        case .noDeviceFound:       return "Nessun robot trovato associato a questo account."
        case .httpError(let code): return "Errore HTTP: \(code)"
        case .networkError(let e): return "Errore di rete: \(e.localizedDescription)"
        case .decodingError:       return "Errore nel parsing della risposta."
        }
    }
}

final class StigaAPIClient {

    static let shared = StigaAPIClient()
    private init() {}

    private(set) var idToken:       String?
    private(set) var currentDevice: StigaDevice?
    private(set) var displayName:   String?

    private let session = URLSession.shared

    func login(email: String,
               password: String,
               completion: @escaping (Result<StigaDevice, StigaError>) -> Void) {

        guard let url = URL(string: "\(Config.firebaseBaseURL)/verifyPassword?key=\(Config.firebaseAPIKey)") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = ["email": email, "password": password, "returnSecureToken": true]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        session.dataTask(with: request) { [weak self] data, response, error in
            guard let self else { return }

            if let error { completion(.failure(.networkError(error))); return }
            guard let data else { completion(.failure(.decodingError)); return }

            let status = (response as? HTTPURLResponse)?.statusCode ?? 0

            if status != 200 {
                if let json   = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let errObj = json["error"] as? [String: Any],
                   let msg    = errObj["message"] as? String {
                    switch msg {
                    case "TOO_MANY_ATTEMPTS_TRY_LATER": completion(.failure(.tooManyAttempts))
                    case "USER_DISABLED":               completion(.failure(.accountDisabled))
                    default:                            completion(.failure(.invalidCredentials))
                    }
                } else {
                    completion(.failure(.invalidCredentials))
                }
                return
            }

            guard let json  = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let token = json["idToken"] as? String else {
                completion(.failure(.decodingError)); return
            }

            self.idToken     = token
            self.displayName = (json["displayName"] as? String) ?? email.components(separatedBy: "@").first

            self.fetchGarage(completion: completion)

        }.resume()
    }

    private func fetchGarage(completion: @escaping (Result<StigaDevice, StigaError>) -> Void) {
        guard let token = idToken,
              let url   = URL(string: "\(Config.stigaBaseURL)/api/garage/integration") else { return }

        var request = URLRequest(url: url)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")

        session.dataTask(with: request) { [weak self] data, response, error in
            guard let self else { return }

            if let error { completion(.failure(.networkError(error))); return }

            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard status == 200, let data else { completion(.failure(.httpError(status))); return }

            guard let json      = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let dataArray = json["data"] as? [[String: Any]],
                  let first     = dataArray.first,
                  let attrs     = first["attributes"] as? [String: Any],
                  let uuid      = attrs["uuid"] as? String else {
                completion(.failure(.noDeviceFound)); return
            }

            let device = StigaDevice(uuid: uuid, name: attrs["name"] as? String ?? "Robot STIGA")
            self.currentDevice = device
            completion(.success(device))

        }.resume()
    }

    func startMowing(completion: @escaping (Result<Void, StigaError>) -> Void) {
        sendCommand("startsession", completion: completion)
    }

    func stopMowing(completion: @escaping (Result<Void, StigaError>) -> Void) {
        sendCommand("endsession", completion: completion)
    }

    private func sendCommand(_ command: String,
                              completion: @escaping (Result<Void, StigaError>) -> Void) {
        guard let token = idToken,
              let uuid  = currentDevice?.uuid,
              let url   = URL(string: "\(Config.stigaBaseURL)/api/devices/\(uuid)/command/\(command)") else {
            completion(.failure(.invalidCredentials)); return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [:]) 

        session.dataTask(with: request) { _, response, error in
            if let error { completion(.failure(.networkError(error))); return }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            (200..<300).contains(status) ? completion(.success(())) : completion(.failure(.httpError(status)))
        }.resume()
    }

    func logout() {
        idToken       = nil
        currentDevice = nil
        displayName   = nil
    }
}
