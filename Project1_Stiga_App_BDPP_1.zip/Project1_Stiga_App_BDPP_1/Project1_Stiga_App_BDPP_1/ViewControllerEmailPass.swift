//
//  ViewControllerEmailPass.swift
//  Project1_Stiga_App_BDPP_1
//
//  Created by Michele Pepe on 16/02/26.
//

import UIKit

class ViewControllerEmailPass: UIViewController {
    @IBAction func Accetta(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let identifier = "ViewControllerRC" // Update this if your storyboard ID is different
        
        guard let vcRC = storyboard.instantiateViewController(withIdentifier: identifier) as? ViewControllerRC else {
            assertionFailure("Couldn't instantiate ViewController_ItaIng with identifier '\(identifier)'. Check the Storyboard ID and class.")
            return
        }
        vcRC.modalPresentationStyle = .fullScreen
        self.present(vcRC, animated: true, completion: nil)
        
    }
    
    let emailField: UITextField = {
        let field = UITextField()
        field.placeholder = "Inserisci l'email"
        field.borderStyle = .roundedRect
        field.keyboardType = .emailAddress
        field.autocapitalizationType = .none
        field.translatesAutoresizingMaskIntoConstraints = false
        return field
    }()

    let passwordField: UITextField = {
        let field = UITextField()
        field.placeholder = "Inserisci la password"
        field.borderStyle = .roundedRect
        field.isSecureTextEntry = true
        field.translatesAutoresizingMaskIntoConstraints = false
        return field
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .black // se vuoi stile come screenshot

        view.addSubview(emailField)
        view.addSubview(passwordField)

        NSLayoutConstraint.activate([
            emailField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emailField.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -140),
            emailField.widthAnchor.constraint(equalToConstant: 280),
            emailField.heightAnchor.constraint(equalToConstant: 44),

            passwordField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            passwordField.topAnchor.constraint(equalTo: emailField.bottomAnchor, constant: 16),
            passwordField.widthAnchor.constraint(equalTo: emailField.widthAnchor),
            passwordField.heightAnchor.constraint(equalTo: emailField.heightAnchor)
        ])
    }
}

