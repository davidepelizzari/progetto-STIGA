//
//  ViewControllerEmailPass.swift
//  Project1_Stiga_App_BDPP_1
//
//  Created by Michele Pepe on 06/02/26.
//

import UIKit

class ViewControllerEmailPass: UIViewController, UITextViewDelegate {

    var prefillEmail: String = ""

    private let gradientLayer: CAGradientLayer = {
        let g = CAGradientLayer()
        g.colors = [
            UIColor(red: 0.04, green: 0.05, blue: 0.08, alpha: 1).cgColor,
            UIColor(red: 0.06, green: 0.08, blue: 0.12, alpha: 1).cgColor
        ]
        g.startPoint = CGPoint(x: 0.3, y: 0)
        g.endPoint   = CGPoint(x: 0.7, y: 1)
        return g
    }()

    private let cardView: UIView = {
        let v = UIView()
        v.backgroundColor    = UIColor(red: 0.11, green: 0.13, blue: 0.17, alpha: 1)
        v.layer.cornerRadius = 24
        v.layer.borderWidth  = 1
        v.layer.borderColor  = UIColor(white: 1, alpha: 0.08).cgColor
        v.layer.shadowColor   = UIColor.black.cgColor
        v.layer.shadowOpacity = 0.5
        v.layer.shadowOffset  = CGSize(width: 0, height: 8)
        v.layer.shadowRadius  = 24
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let backButton: UIButton = {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        b.tintColor = UIColor(white: 0.75, alpha: 1)
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    private let titleLabel: UILabel = {
        let l = UILabel()
        l.text          = "Bentornato"
        l.font          = UIFont.systemFont(ofSize: 32, weight: .bold)
        l.textColor     = .white
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private let subtitleLabel: UILabel = {
        let l = UILabel()
        l.text          = "Inserisci le tue credenziali per accedere al pannello di controllo del tuo robot."
        l.font          = UIFont.systemFont(ofSize: 15, weight: .regular)
        l.textColor     = UIColor(white: 0.50, alpha: 1)
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private let emailContainer: UIView = {
        let v = UIView()
        v.backgroundColor    = UIColor(red: 0.14, green: 0.16, blue: 0.21, alpha: 1)
        v.layer.cornerRadius = 16
        v.layer.borderWidth  = 1
        v.layer.borderColor  = UIColor(white: 1, alpha: 0.10).cgColor
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let emailIconView: UIImageView = {
        let iv = UIImageView()
        iv.image       = UIImage(systemName: "envelope")
        iv.tintColor   = UIColor(white: 0.45, alpha: 1)
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let emailField: UITextField = {
        let f = UITextField()
        f.keyboardType           = .emailAddress
        f.autocapitalizationType = .none
        f.autocorrectionType     = .no
        f.textColor              = .white
        f.tintColor              = UIColor(white: 0.80, alpha: 1)
        f.font                   = UIFont.systemFont(ofSize: 16)
        f.backgroundColor        = .clear
        f.borderStyle            = .none
        f.attributedPlaceholder  = NSAttributedString(
            string: "Indirizzo e-mail",
            attributes: [.foregroundColor: UIColor(white: 0.38, alpha: 1)]
        )
        f.translatesAutoresizingMaskIntoConstraints = false
        return f
    }()

    private let passwordContainer: UIView = {
        let v = UIView()
        v.backgroundColor    = UIColor(red: 0.14, green: 0.16, blue: 0.21, alpha: 1)
        v.layer.cornerRadius = 16
        v.layer.borderWidth  = 1
        v.layer.borderColor  = UIColor(white: 1, alpha: 0.10).cgColor
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let passwordIconView: UIImageView = {
        let iv = UIImageView()
        iv.image       = UIImage(systemName: "lock")
        iv.tintColor   = UIColor(white: 0.45, alpha: 1)
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let passwordField: UITextField = {
        let f = UITextField()
        f.isSecureTextEntry      = true
        f.autocapitalizationType = .none
        f.autocorrectionType     = .no
        f.textColor              = .white
        f.tintColor              = UIColor(white: 0.80, alpha: 1)
        f.font                   = UIFont.systemFont(ofSize: 16)
        f.backgroundColor        = .clear
        f.borderStyle            = .none
        f.attributedPlaceholder  = NSAttributedString(
            string: "Password",
            attributes: [.foregroundColor: UIColor(white: 0.38, alpha: 1)]
        )
        f.translatesAutoresizingMaskIntoConstraints = false
        return f
    }()

    private let eyeButton: UIButton = {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: "eye"), for: .normal)
        b.tintColor = UIColor(white: 0.45, alpha: 1)
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    private let continueButton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("CONTINUA", for: .normal)
        b.setTitleColor(.white, for: .normal)
        b.titleLabel?.font   = UIFont.systemFont(ofSize: 15, weight: .bold)
        b.backgroundColor    = UIColor(red: 0.20, green: 0.22, blue: 0.28, alpha: 1)
        b.layer.cornerRadius = 28
        b.layer.borderWidth  = 1
        b.layer.borderColor  = UIColor(white: 1, alpha: 0.12).cgColor
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    private let spinner: UIActivityIndicatorView = {
        let a = UIActivityIndicatorView(style: .medium)
        a.color = .white
        a.hidesWhenStopped = true
        a.translatesAutoresizingMaskIntoConstraints = false
        return a
    }()

    private let errorLabel: UILabel = {
        let l = UILabel()
        l.font          = UIFont.systemFont(ofSize: 13, weight: .medium)
        l.textColor     = UIColor(red: 0.97, green: 0.40, blue: 0.40, alpha: 1)
        l.numberOfLines = 0
        l.isHidden      = true
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private lazy var legalTextView: UITextView = {
        let tv = UITextView()
        tv.backgroundColor    = .clear
        tv.isEditable         = false
        tv.isScrollEnabled    = false
        tv.textAlignment      = .center
        tv.textContainerInset = .zero
        tv.textContainer.lineFragmentPadding = 0
        tv.translatesAutoresizingMaskIntoConstraints = false

        let base = "Continuando, confermo di aver letto e accettato le Informativa sulla privacy e Contratto di licenza."
        let attr = NSMutableAttributedString(
            string: base,
            attributes: [
                .font: UIFont.systemFont(ofSize: 13),
                .foregroundColor: UIColor(white: 0.42, alpha: 1)
            ]
        )
        if let r = base.range(of: "Informativa sulla privacy") {
            attr.addAttributes([
                .link: "action://privacy",
                .foregroundColor: UIColor(white: 0.85, alpha: 1),
                .underlineStyle: NSUnderlineStyle.single.rawValue
            ], range: NSRange(r, in: base))
        }
        if let r = base.range(of: "Contratto di licenza") {
            attr.addAttributes([
                .link: "action://license",
                .foregroundColor: UIColor(white: 0.85, alpha: 1),
                .underlineStyle: NSUnderlineStyle.single.rawValue
            ], range: NSRange(r, in: base))
        }
        tv.attributedText = attr
        tv.linkTextAttributes = [
            .foregroundColor: UIColor(white: 0.85, alpha: 1),
            .underlineStyle: NSUnderlineStyle.single.rawValue
        ]
        return tv
    }()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setupGradient()
        buildLayout()
        wireActions()
        legalTextView.delegate = self
        if !prefillEmail.isEmpty {
            emailField.text = prefillEmail
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gradientLayer.frame = view.bounds
    }

    // MARK: - UITextViewDelegate

    func textView(_ textView: UITextView,
                  shouldInteractWith URL: URL,
                  in characterRange: NSRange,
                  interaction: UITextItemInteraction) -> Bool {
        switch URL.absoluteString {
        case "action://privacy": openLegal(.privacy)
        case "action://license": openLegal(.license)
        default: break
        }
        return false
    }

    // MARK: - Setup

    private func setupGradient() {
        view.layer.insertSublayer(gradientLayer, at: 0)
    }

    private func buildLayout() {
        emailContainer.addSubview(emailIconView)
        emailContainer.addSubview(emailField)
        passwordContainer.addSubview(passwordIconView)
        passwordContainer.addSubview(passwordField)
        passwordContainer.addSubview(eyeButton)

        view.addSubview(cardView)
        view.addSubview(backButton)
        [titleLabel, subtitleLabel,
         emailContainer, passwordContainer, errorLabel,
         continueButton, spinner, legalTextView].forEach { cardView.addSubview($0) }

        let p: CGFloat = 24

        NSLayoutConstraint.activate([
            backButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            backButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            backButton.widthAnchor.constraint(equalToConstant: 44),
            backButton.heightAnchor.constraint(equalToConstant: 44),

            cardView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            cardView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 32),
            cardView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -32),

            titleLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 28),
            titleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            titleLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),

            subtitleLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
            subtitleLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            subtitleLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),

            emailContainer.topAnchor.constraint(equalTo: subtitleLabel.bottomAnchor, constant: 24),
            emailContainer.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            emailContainer.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),
            emailContainer.heightAnchor.constraint(equalToConstant: 56),

            emailIconView.leadingAnchor.constraint(equalTo: emailContainer.leadingAnchor, constant: 16),
            emailIconView.centerYAnchor.constraint(equalTo: emailContainer.centerYAnchor),
            emailIconView.widthAnchor.constraint(equalToConstant: 18),
            emailIconView.heightAnchor.constraint(equalToConstant: 18),

            emailField.leadingAnchor.constraint(equalTo: emailIconView.trailingAnchor, constant: 10),
            emailField.trailingAnchor.constraint(equalTo: emailContainer.trailingAnchor, constant: -16),
            emailField.centerYAnchor.constraint(equalTo: emailContainer.centerYAnchor),

            passwordContainer.topAnchor.constraint(equalTo: emailContainer.bottomAnchor, constant: 12),
            passwordContainer.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            passwordContainer.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),
            passwordContainer.heightAnchor.constraint(equalToConstant: 56),

            passwordIconView.leadingAnchor.constraint(equalTo: passwordContainer.leadingAnchor, constant: 16),
            passwordIconView.centerYAnchor.constraint(equalTo: passwordContainer.centerYAnchor),
            passwordIconView.widthAnchor.constraint(equalToConstant: 18),
            passwordIconView.heightAnchor.constraint(equalToConstant: 18),

            passwordField.leadingAnchor.constraint(equalTo: passwordIconView.trailingAnchor, constant: 10),
            passwordField.trailingAnchor.constraint(equalTo: eyeButton.leadingAnchor, constant: -8),
            passwordField.centerYAnchor.constraint(equalTo: passwordContainer.centerYAnchor),

            eyeButton.trailingAnchor.constraint(equalTo: passwordContainer.trailingAnchor, constant: -14),
            eyeButton.centerYAnchor.constraint(equalTo: passwordContainer.centerYAnchor),
            eyeButton.widthAnchor.constraint(equalToConstant: 28),
            eyeButton.heightAnchor.constraint(equalToConstant: 28),

            errorLabel.topAnchor.constraint(equalTo: passwordContainer.bottomAnchor, constant: 8),
            errorLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            errorLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),

            continueButton.topAnchor.constraint(equalTo: errorLabel.bottomAnchor, constant: 18),
            continueButton.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            continueButton.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),
            continueButton.heightAnchor.constraint(equalToConstant: 56),

            spinner.centerXAnchor.constraint(equalTo: continueButton.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: continueButton.centerYAnchor),

            legalTextView.topAnchor.constraint(equalTo: continueButton.bottomAnchor, constant: 20),
            legalTextView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: p),
            legalTextView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -p),
            legalTextView.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -28)
        ])
    }

    private func wireActions() {
        backButton.addTarget(self, action: #selector(backTapped), for: .touchUpInside)
        continueButton.addTarget(self, action: #selector(loginTapped), for: .touchUpInside)
        eyeButton.addTarget(self, action: #selector(togglePassword), for: .touchUpInside)
        emailField.addTarget(self, action: #selector(clearError), for: .editingChanged)
        passwordField.addTarget(self, action: #selector(clearError), for: .editingChanged)
        passwordField.addTarget(self, action: #selector(loginTapped), for: .editingDidEndOnExit)
        emailField.addTarget(self, action: #selector(fieldActive(_:)), for: .editingDidBegin)
        emailField.addTarget(self, action: #selector(fieldInactive(_:)), for: .editingDidEnd)
        passwordField.addTarget(self, action: #selector(fieldActive(_:)), for: .editingDidBegin)
        passwordField.addTarget(self, action: #selector(fieldInactive(_:)), for: .editingDidEnd)

        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }

    // MARK: - Actions

    @objc private func backTapped() {
        dismiss(animated: true)
    }

    @objc private func togglePassword() {
        passwordField.isSecureTextEntry.toggle()
        let name = passwordField.isSecureTextEntry ? "eye" : "eye.slash"
        eyeButton.setImage(UIImage(systemName: name), for: .normal)
    }

    @objc private func loginTapped() {
        dismissKeyboard()
        clearError()

        let email    = emailField.text?.trimmingCharacters(in: .whitespaces) ?? ""
        let password = passwordField.text ?? ""

        guard !email.isEmpty, !password.isEmpty else {
            showError("Inserisci email e password per continuare.")
            shake(email.isEmpty ? emailContainer : passwordContainer)
            return
        }

        setLoading(true)

        StigaAPIClient.shared.login(email: email, password: password) { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                self.setLoading(false)
                switch result {
                case .success(let device): self.navigateToRC(device: device)
                case .failure(let error):  self.showError(error.localizedDescription); self.shake(self.passwordContainer)
                }
            }
        }
    }

    private func openLegal(_ document: LegalDocument) {
        let vc = LegalWebViewController()
        vc.document = document
        vc.modalPresentationStyle = .pageSheet
        if let sheet = vc.sheetPresentationController {
            sheet.detents = [.large()]
            sheet.prefersGrabberVisible = true
        }
        present(vc, animated: true)
    }

    private func navigateToRC(device: StigaDevice) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        guard let vcRC = sb.instantiateViewController(withIdentifier: "ViewControllerRC") as? ViewControllerRC else {
            assertionFailure("Storyboard ID 'ViewControllerRC' non trovato.")
            return
        }
        vcRC.device                 = device
        vcRC.userName               = StigaAPIClient.shared.displayName ?? ""
        vcRC.modalPresentationStyle = .fullScreen
        present(vcRC, animated: true)
    }

    @objc private func dismissKeyboard() { view.endEditing(true) }
    @objc private func clearError()      { errorLabel.isHidden = true }

    @objc private func fieldActive(_ sender: UITextField) {
        let container = sender == emailField ? emailContainer : passwordContainer
        UIView.animate(withDuration: 0.2) { container.layer.borderColor = UIColor(white: 1, alpha: 0.35).cgColor }
    }

    @objc private func fieldInactive(_ sender: UITextField) {
        let container = sender == emailField ? emailContainer : passwordContainer
        UIView.animate(withDuration: 0.2) { container.layer.borderColor = UIColor(white: 1, alpha: 0.10).cgColor }
    }

    private func showError(_ msg: String) { errorLabel.text = msg; errorLabel.isHidden = false }

    private func setLoading(_ loading: Bool) {
        continueButton.isEnabled = !loading
        continueButton.setTitle(loading ? "" : "CONTINUA", for: .normal)
        loading ? spinner.startAnimating() : spinner.stopAnimating()
    }

    private func shake(_ v: UIView) {
        let anim = CAKeyframeAnimation(keyPath: "transform.translation.x")
        anim.timingFunction = CAMediaTimingFunction(name: .linear)
        anim.duration = 0.38
        anim.values   = [-8, 8, -5, 5, -3, 3, 0]
        v.layer.add(anim, forKey: "shake")
    }
}
