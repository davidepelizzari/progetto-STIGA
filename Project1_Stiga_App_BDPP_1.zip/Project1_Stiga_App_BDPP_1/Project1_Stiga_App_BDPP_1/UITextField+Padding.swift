//
//  UITextField+Padding.swift
//  Project1_Stiga_App_BDPP_1
//
//  Created by Xcode Assistant on 06/02/26.
//

import UIKit

public extension UITextField {
    /// Adds left padding by setting a leftView with the given width.
    func setLeftPadding(_ amount: CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }

    /// Adds right padding by setting a rightView with the given width.
    func setRightPadding(_ amount: CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}
