//
//  ViewControllerRC.swift
//  Project1_Stiga_App_BDPP_1
//
//  Created by Michele Pepe on 16/02/26.
//

import UIKit

class ViewControllerRC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
