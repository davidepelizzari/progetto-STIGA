//
//  ViewControllerRC.swift
//  Project1_Stiga_App_BDPP_1
//
//  Created by Michele Pepe on 16/02/26.
//

import UIKit

class ViewControllerRC: UIViewController {

    var device:   StigaDevice = StigaDevice(uuid: "", name: "Robot STIGA")
    var userName: String      = ""

    private var isRunning = false

    private let welcomeLabel: UILabel = {
        let l = UILabel()
        l.font          = .systemFont(ofSize: 14, weight: .regular)
        l.textColor     = UIColor.lightGray
        l.textAlignment = .left
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private let robotCard: UIView = {
        let v = UIView()
        v.backgroundColor    = UIColor(white: 0.1, alpha: 1)
        v.layer.cornerRadius = 16
        v.layer.borderWidth  = 1
        v.layer.borderColor  = UIColor(white: 0.2, alpha: 1).cgColor
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let robotNameLabel: UILabel = {
        let l = UILabel()
        l.font      = .systemFont(ofSize: 16, weight: .bold)
        l.textColor = .white
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private let robotSubLabel: UILabel = {
        let l = UILabel()
        l.text      = "Robot tagliaerba"
        l.font      = .systemFont(ofSize: 12, weight: .regular)
        l.textColor = UIColor.lightGray
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private let statusBadge: UILabel = {
        let l = UILabel()
        l.text               = "In attesa"
        l.font               = .systemFont(ofSize: 11, weight: .semibold)
        l.textColor          = UIColor.lightGray
        l.backgroundColor    = UIColor(white: 0.15, alpha: 1)
        l.layer.cornerRadius = 10
        l.layer.masksToBounds = true
        l.textAlignment      = .center
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private let startButton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("▶  Avvia", for: .normal)
        b.setTitleColor(UIColor(red: 0.27, green: 0.76, blue: 0.37, alpha: 1), for: .normal)
        b.titleLabel?.font   = .systemFont(ofSize: 15, weight: .bold)
        b.backgroundColor    = UIColor(red: 0.27, green: 0.76, blue: 0.37, alpha: 0.1)
        b.layer.cornerRadius = 14
        b.layer.borderWidth  = 1
        b.layer.borderColor  = UIColor(red: 0.27, green: 0.76, blue: 0.37, alpha: 0.3).cgColor
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    private let stopButton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("■  Ferma", for: .normal)
        b.setTitleColor(UIColor(red: 0.94, green: 0.27, blue: 0.27, alpha: 1), for: .normal)
        b.titleLabel?.font   = .systemFont(ofSize: 15, weight: .bold)
        b.backgroundColor    = UIColor(red: 0.94, green: 0.27, blue: 0.27, alpha: 0.1)
        b.layer.cornerRadius = 14
        b.layer.borderWidth  = 1
        b.layer.borderColor  = UIColor(red: 0.94, green: 0.27, blue: 0.27, alpha: 0.25).cgColor
        b.isHidden           = true
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    private let activityIndicator: UIActivityIndicatorView = {
        let a = UIActivityIndicatorView(style: .medium)
        a.color            = .white
        a.hidesWhenStopped = true
        a.translatesAutoresizingMaskIntoConstraints = false
        return a
    }()

    private let separatorLine: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(white: 0.2, alpha: 1)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let logoutButton: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("Disconnetti", for: .normal)
        b.setTitleColor(UIColor.lightGray, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 13, weight: .medium)
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    private let toastLabel: UILabel = {
        let l = UILabel()
        l.font               = .systemFont(ofSize: 13, weight: .medium)
        l.textColor          = .white
        l.backgroundColor    = UIColor(white: 0.15, alpha: 0.95)
        l.layer.cornerRadius = 20
        l.layer.masksToBounds = true
        l.textAlignment      = .center
        l.alpha              = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupLayout()
        populateData()

        startButton.addTarget(self, action: #selector(startTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopTapped), for: .touchUpInside)
        logoutButton.addTarget(self, action: #selector(logoutTapped), for: .touchUpInside)
    }

    private func setupLayout() {
        robotCard.addSubview(robotNameLabel)
        robotCard.addSubview(robotSubLabel)
        robotCard.addSubview(statusBadge)

        let centerContainer = UIView()
        centerContainer.translatesAutoresizingMaskIntoConstraints = false

        [welcomeLabel, robotCard, startButton, stopButton,
         activityIndicator, separatorLine, logoutButton].forEach { centerContainer.addSubview($0) }

        view.addSubview(centerContainer)
        view.addSubview(toastLabel)

        let h: CGFloat = 24

        NSLayoutConstraint.activate([

            centerContainer.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor),
            centerContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            centerContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            welcomeLabel.topAnchor.constraint(equalTo: centerContainer.topAnchor),
            welcomeLabel.leadingAnchor.constraint(equalTo: centerContainer.leadingAnchor, constant: 28),
            welcomeLabel.trailingAnchor.constraint(equalTo: centerContainer.trailingAnchor, constant: -28),

            robotCard.topAnchor.constraint(equalTo: welcomeLabel.bottomAnchor, constant: 20),
            robotCard.leadingAnchor.constraint(equalTo: centerContainer.leadingAnchor, constant: h),
            robotCard.trailingAnchor.constraint(equalTo: centerContainer.trailingAnchor, constant: -h),
            robotCard.heightAnchor.constraint(equalToConstant: 72),

            robotNameLabel.leadingAnchor.constraint(equalTo: robotCard.leadingAnchor, constant: 16),
            robotNameLabel.topAnchor.constraint(equalTo: robotCard.topAnchor, constant: 16),

            robotSubLabel.leadingAnchor.constraint(equalTo: robotCard.leadingAnchor, constant: 16),
            robotSubLabel.topAnchor.constraint(equalTo: robotNameLabel.bottomAnchor, constant: 4),

            statusBadge.trailingAnchor.constraint(equalTo: robotCard.trailingAnchor, constant: -16),
            statusBadge.centerYAnchor.constraint(equalTo: robotCard.centerYAnchor),
            statusBadge.widthAnchor.constraint(equalToConstant: 88),
            statusBadge.heightAnchor.constraint(equalToConstant: 28),

            startButton.topAnchor.constraint(equalTo: robotCard.bottomAnchor, constant: 20),
            startButton.leadingAnchor.constraint(equalTo: centerContainer.leadingAnchor, constant: h),
            startButton.trailingAnchor.constraint(equalTo: centerContainer.trailingAnchor, constant: -h),
            startButton.heightAnchor.constraint(equalToConstant: 52),

            stopButton.topAnchor.constraint(equalTo: robotCard.bottomAnchor, constant: 20),
            stopButton.leadingAnchor.constraint(equalTo: centerContainer.leadingAnchor, constant: h),
            stopButton.trailingAnchor.constraint(equalTo: centerContainer.trailingAnchor, constant: -h),
            stopButton.heightAnchor.constraint(equalToConstant: 52),

            activityIndicator.centerXAnchor.constraint(equalTo: startButton.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: startButton.centerYAnchor),

            separatorLine.topAnchor.constraint(equalTo: startButton.bottomAnchor, constant: 24),
            separatorLine.leadingAnchor.constraint(equalTo: centerContainer.leadingAnchor, constant: h),
            separatorLine.trailingAnchor.constraint(equalTo: centerContainer.trailingAnchor, constant: -h),
            separatorLine.heightAnchor.constraint(equalToConstant: 1),

            logoutButton.topAnchor.constraint(equalTo: separatorLine.bottomAnchor, constant: 16),
            logoutButton.leadingAnchor.constraint(equalTo: centerContainer.leadingAnchor, constant: h),
            logoutButton.bottomAnchor.constraint(equalTo: centerContainer.bottomAnchor),

            toastLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -28),
            toastLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            toastLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 200),
            toastLabel.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    private func populateData() {
        let name = userName.isEmpty ? "Utente" : userName
        welcomeLabel.text   = "Benvenuto, \(name) 👋"
        robotNameLabel.text = device.name
    }

    @objc private func startTapped() {
        setLoading(true)

        StigaAPIClient.shared.startMowing { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                self.setLoading(false)

                switch result {
                case .success:
                    self.isRunning = true
                    self.updateRunningState()
                    self.showToast("✓ Robot avviato", success: true)
                case .failure(let error):
                    
                    self.showToast(error.localizedDescription, success: false)
                }
            }
        }
    }

    @objc private func stopTapped() {
        setLoading(true)
        updateStatus("Fermando…", color: UIColor(red: 0.94, green: 0.27, blue: 0.27, alpha: 1))

        StigaAPIClient.shared.stopMowing { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                self.setLoading(false)
                self.isRunning = false
                self.updateRunningState()

                switch result {
                case .success:
                    self.showToast("✓ Robot fermato", success: true)
                case .failure(let error):
                    self.showToast(error.localizedDescription, success: false)
                }
            }
        }
    }

    @objc private func logoutTapped() {
        StigaAPIClient.shared.logout()

        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let vcLogin = storyboard.instantiateViewController(
            withIdentifier: "ViewControllerLoginPage"
        ) as? ViewControllerLoginPage else {
            dismiss(animated: true)
            return
        }
        vcLogin.modalPresentationStyle = .fullScreen
        present(vcLogin, animated: true)
    }

    private func updateRunningState() {
        if isRunning {
            startButton.isHidden = true
            stopButton.isHidden  = false
            updateStatus("In movimento", color: UIColor(red: 0.27, green: 0.76, blue: 0.37, alpha: 1))
        } else {
            startButton.isHidden = false
            stopButton.isHidden  = true
            updateStatus("In attesa", color: UIColor.lightGray)
        }
    }

    private func updateStatus(_ text: String, color: UIColor) {
        statusBadge.text      = text
        statusBadge.textColor = color
    }

    private func setLoading(_ loading: Bool) {
        startButton.isEnabled = !loading
        stopButton.isEnabled  = !loading
        loading ? activityIndicator.startAnimating() : activityIndicator.stopAnimating()
    }

    private func showToast(_ msg: String, success: Bool) {
        toastLabel.text      = msg
        toastLabel.textColor = success
            ? UIColor(red: 0.3, green: 0.87, blue: 0.45, alpha: 1)
            : UIColor(red: 0.97, green: 0.53, blue: 0.53, alpha: 1)

        UIView.animate(withDuration: 0.3, animations: {
            self.toastLabel.alpha = 1
        }) { _ in
            UIView.animate(withDuration: 0.4, delay: 2.5, animations: {
                self.toastLabel.alpha = 0
            })
        }
    }
}
