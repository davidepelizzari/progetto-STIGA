//
//  LegalWebViewController.swift
//  Project1_Stiga_App_BDPP_1
//
//  Created by Michele Pepe on 31/03/26.
//

import UIKit
import WebKit

enum LegalDocument {
    case privacy
    case license

    var title: String {
        switch self {
        case .privacy:  return "Informativa sulla Privacy"
        case .license:  return "Contratto di Licenza"
        }
    }

    var htmlContent: String {
        switch self {
        case .privacy:  return LegalHTMLContent.privacy
        case .license:  return LegalHTMLContent.license
        }
    }
}

final class LegalWebViewController: UIViewController {

    var document: LegalDocument = .privacy

    private let navBar: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(red: 0.07, green: 0.09, blue: 0.13, alpha: 1)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let navTitle: UILabel = {
        let l = UILabel()
        l.font      = UIFont.systemFont(ofSize: 16, weight: .semibold)
        l.textColor = .white
        l.textAlignment = .center
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()

    private let closeButton: UIButton = {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: "xmark"), for: .normal)
        b.tintColor = UIColor(white: 0.7, alpha: 1)
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()

    private let separator: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(white: 1, alpha: 0.08)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private lazy var webView: WKWebView = {
        let config = WKWebViewConfiguration()
        let wv = WKWebView(frame: .zero, configuration: config)
        wv.backgroundColor = UIColor(red: 0.04, green: 0.05, blue: 0.08, alpha: 1)
        wv.scrollView.backgroundColor = UIColor(red: 0.04, green: 0.05, blue: 0.08, alpha: 1)
        wv.isOpaque = false
        wv.translatesAutoresizingMaskIntoConstraints = false
        return wv
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.04, green: 0.05, blue: 0.08, alpha: 1)
        buildLayout()
        navTitle.text = document.title
        webView.loadHTMLString(document.htmlContent, baseURL: nil)
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
    }

    private func buildLayout() {
        navBar.addSubview(navTitle)
        navBar.addSubview(closeButton)
        navBar.addSubview(separator)

        view.addSubview(navBar)
        view.addSubview(webView)

        NSLayoutConstraint.activate([
            navBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            navBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            navBar.heightAnchor.constraint(equalToConstant: 52),

            navTitle.centerXAnchor.constraint(equalTo: navBar.centerXAnchor),
            navTitle.centerYAnchor.constraint(equalTo: navBar.centerYAnchor),

            closeButton.trailingAnchor.constraint(equalTo: navBar.trailingAnchor, constant: -16),
            closeButton.centerYAnchor.constraint(equalTo: navBar.centerYAnchor),
            closeButton.widthAnchor.constraint(equalToConstant: 32),
            closeButton.heightAnchor.constraint(equalToConstant: 32),

            separator.bottomAnchor.constraint(equalTo: navBar.bottomAnchor),
            separator.leadingAnchor.constraint(equalTo: navBar.leadingAnchor),
            separator.trailingAnchor.constraint(equalTo: navBar.trailingAnchor),
            separator.heightAnchor.constraint(equalToConstant: 1),

            webView.topAnchor.constraint(equalTo: navBar.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    @objc private func closeTapped() {
        dismiss(animated: true)
    }
}

enum LegalHTMLContent {

    static let privacy = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy</title>
    <style>
      :root {
        --blue: #3B6FFF;
        --surface: #0d1117;
        --surface2: #161b22;
        --border: #222833;
        --text: #ffffff;
        --text-mid: #c9d1d9;
        --text-muted: #8b949e;
        --radius: 16px;
      }
      *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
      body {
        background: #05070d;
        color: var(--text);
        font-family: -apple-system, 'Helvetica Neue', sans-serif;
        padding: 24px 20px 48px;
        font-size: 15px;
        line-height: 1.7;
      }
      .tag {
        display: inline-flex; align-items: center; gap: 6px;
        background: rgba(59,111,255,0.12);
        border: 1px solid rgba(59,111,255,0.25);
        border-radius: 20px; padding: 5px 12px;
        font-size: 11px; font-weight: 600;
        color: #7aa3ff; letter-spacing: .4px; margin-bottom: 14px;
      }
      h1 { font-size: 26px; font-weight: 700; color: var(--text); margin-bottom: 8px; }
      .intro { font-size: 13px; color: var(--text-muted); margin-bottom: 28px; }
      .section { margin-bottom: 28px; }
      .section h2 {
        font-size: 14px; font-weight: 700; color: var(--text);
        padding: 10px 0; border-bottom: 1px solid var(--border);
        display: flex; align-items: center; gap: 8px; margin-bottom: 12px;
      }
      .num {
        display: inline-flex; align-items: center; justify-content: center;
        width: 22px; height: 22px;
        background: rgba(59,111,255,0.12); border: 1px solid rgba(59,111,255,0.2);
        border-radius: 7px; font-size: 10px; font-weight: 700; color: #7aa3ff;
      }
      p { font-size: 13.5px; color: var(--text-muted); margin-bottom: 10px; }
      ul { list-style: none; padding: 0; margin: 8px 0 10px 0; display: flex; flex-direction: column; gap: 6px; }
      li { font-size: 13.5px; color: var(--text-muted); padding-left: 14px; position: relative; }
      li::before { content: ''; position: absolute; left: 0; top: 9px; width: 5px; height: 5px; border-radius: 50%; background: rgba(59,111,255,0.5); }
      strong { color: var(--text-mid); font-weight: 600; }
      a { color: #7aa3ff; }
      .info-box { background: var(--surface2); border: 1px solid var(--border); border-radius: 10px; padding: 14px 16px; margin: 10px 0; }
      .info-box p { margin-bottom: 4px; font-size: 13px; }
      table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 12.5px; }
      th { background: var(--surface2); color: var(--text-mid); font-weight: 600; padding: 9px 12px; text-align: left; border: 1px solid var(--border); }
      td { padding: 9px 12px; border: 1px solid var(--border); color: var(--text-muted); vertical-align: top; }
      tr:nth-child(even) td { background: rgba(255,255,255,0.015); }
      .footer { margin-top: 28px; font-size: 11.5px; color: var(--text-muted); border-top: 1px solid var(--border); padding-top: 16px; }
    </style>
    </head>
    <body>
      <div class="tag">GDPR — Regulation (EU) 2016/679</div>
      <h1>Privacy Policy</h1>
      <p class="intro">In accordance with article 13 of Regulation (EU) 2016/679. This policy relates exclusively to the processing of personal data collected through <strong>www.stiga.com/int/</strong>.</p>

      <div class="section">
        <h2><span class="num">1</span> Social Media</h2>
        <p>The Site uses social media widgets (Facebook, Twitter, Instagram, Pinterest, LinkedIn). The widgets only transmit data to the respective social media when you activate them by clicking the corresponding button. If you are simultaneously logged in, the provider can attribute visits to your account. The Company and the social media outlet act as <strong>joint data controllers</strong> (art. 26 GDPR). Legal basis: your consent, withdrawable via the Cookie Policy.</p>
      </div>

      <div class="section">
        <h2><span class="num">2</span> Data Controller</h2>
        <div class="info-box">
          <p><strong>Stiga S.p.A.</strong></p>
          <p>Via del Lavoro 6, 31033 Castelfranco Veneto (TV), Italy</p>
          <p>E-mail: <a href="mailto:info@stiga.com">info@stiga.com</a></p>
        </div>
        <p>The Data Controller has appointed a <strong>Data Protection Officer (DPO)</strong>:</p>
        <div class="info-box">
          <p><strong>DPO Office</strong> — Stiga S.p.A., Via del Lavoro 6, 31033 Castelfranco Veneto, Italy</p>
          <p>E-mail: <a href="mailto:dpo@stiga.com">dpo@stiga.com</a></p>
        </div>
      </div>

      <div class="section">
        <h2><span class="num">3</span> Personal Data We Process</h2>
        <ul>
          <li><strong>Personal Identifiable Information:</strong> first name, surname, address</li>
          <li><strong>Contact details:</strong> residential address, e-mail, telephone number</li>
          <li><strong>Data on interests and preferences:</strong> purchases, products in cart</li>
          <li><strong>Transactional data:</strong> credit card number, tax code</li>
        </ul>
        <p><strong>Browsing data:</strong> IP addresses, domain names, URI addresses, server response codes. Used solely for anonymous statistics and deleted immediately after processing. Web contact data stored for no longer than <strong>seven days</strong>.</p>
        <p><strong>Cookies:</strong> Some pages use cookies for technical functioning, usability and statistical analysis. See Cookie Policy for details.</p>
      </div>

      <div class="section">
        <h2><span class="num">4</span> Purposes and Legal Bases</h2>
        <p><strong>4.1 Handling your requests</strong> — Via the "Contact Us" form. Legal basis: art. 6(1)(b) or (f) GDPR. No consent required.</p>
        <p><strong>4.2 Marketing and soft spam</strong> — Newsletters, e-mails, etc., with your consent. Withdraw at any time: <a href="mailto:unsubscribe@stiga.com">unsubscribe@stiga.com</a>. Legal basis: art. 6(1)(a) GDPR.</p>
        <p><strong>4.3 Preference analysis</strong> — Analysis of purchasing preferences. Legal basis: art. 6(1)(a) GDPR — consent may be withdrawn at any time.</p>
        <p><strong>4.4 Statistical analysis</strong> — To improve products and services. Legal basis: legitimate interest, art. 6(1)(f) GDPR.</p>
        <p><strong>4.5 "My Stiga" account</strong> — Account creation and product/warranty registration. Legal basis: art. 6(1)(b) GDPR.</p>
        <p><strong>4.6 E-commerce</strong> — Sales process, legal obligations, contractual rights. Legal bases: art. 6(1)(b), (c) and (f) GDPR.</p>
      </div>

      <div class="section">
        <h2><span class="num">5</span> Retention Period</h2>
        <table>
          <thead><tr><th>Purpose</th><th>Period</th></tr></thead>
          <tbody>
            <tr><td>4.1 — Handling requests</td><td>Max <strong>5 years</strong> after request.</td></tr>
            <tr><td>4.2 — Marketing</td><td>Duration of subscription.</td></tr>
            <tr><td>4.4 — Statistical analysis</td><td>Max <strong>5 years</strong>.</td></tr>
            <tr><td>4.5 — My Stiga account</td><td>Duration of registration; erased after <strong>5 years of inactivity</strong>.</td></tr>
            <tr><td>4.6 — E-commerce</td><td>As long as necessary per legal obligations.</td></tr>
          </tbody>
        </table>
      </div>

      <div class="section">
        <h2><span class="num">6</span> Processing Procedures</h2>
        <p>Data is processed in accordance with the GDPR by means of paper, computer and telematic tools guaranteeing security per art. 32 GDPR. Analysis activities always involve duly authorised natural persons. Third-party processors include:</p>
        <ul>
          <li>Companies managing the company's information systems</li>
          <li>Payment service managers</li>
          <li>Legal, tax and accounting consultants</li>
          <li>Shipping and delivery companies</li>
          <li>E-commerce platform providers</li>
        </ul>
        <p>Request the list of processors at: <a href="mailto:unsubscribe@stiga.com">unsubscribe@stiga.com</a>.</p>
      </div>

      <div class="section">
        <h2><span class="num">7</span> Your Rights</h2>
        <p>Contact <a href="mailto:unsubscribe@stiga.com">unsubscribe@stiga.com</a> to exercise:</p>
        <ul>
          <li><strong>Right of access (art. 15)</strong></li>
          <li><strong>Right to rectification (art. 16)</strong></li>
          <li><strong>Right to erasure / right to be forgotten (art. 17)</strong></li>
          <li><strong>Right to restriction of processing (art. 18)</strong></li>
          <li><strong>Right to data portability (art. 20)</strong></li>
          <li><strong>Right to lodge a complaint</strong> — Italian DPA: Piazza di Monte Citorio 121, 00186 Rome — <a href="mailto:protocollo@pec.gpdp.it">protocollo@pec.gpdp.it</a></li>
        </ul>
      </div>

      <div class="section">
        <h2><span class="num">8</span> Revision Clause</h2>
        <p>The Company reserves the right to revise this Privacy Policy at any time. Users will be notified of changes when adopted and posted on the Site.</p>
      </div>

      <div class="footer">Privacy Policy — Stiga S.p.A. · Via del Lavoro 6, 31033 Castelfranco Veneto (TV) · <a href="mailto:dpo@stiga.com">dpo@stiga.com</a></div>
    </body>
    </html>
    """

    static let license = """
    <!DOCTYPE html>
    <html lang="it">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contratto di Licenza</title>
    <style>
      :root {
        --blue: #3B6FFF;
        --surface2: #161b22;
        --border: #222833;
        --text: #ffffff;
        --text-mid: #c9d1d9;
        --text-muted: #8b949e;
      }
      *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
      body {
        background: #05070d;
        color: var(--text);
        font-family: -apple-system, 'Helvetica Neue', sans-serif;
        padding: 24px 20px 48px;
        font-size: 15px;
        line-height: 1.7;
      }
      h1 { font-size: 26px; font-weight: 700; margin-bottom: 4px; }
      .meta { font-size: 13px; color: var(--text-muted); margin-bottom: 20px; }
      .info-box {
        background: rgba(59,111,255,0.07);
        border: 1px solid rgba(59,111,255,0.18);
        border-radius: 10px; padding: 12px 16px;
        font-size: 13px; color: #93b4ff;
        margin-bottom: 24px;
      }
      .section { margin-bottom: 24px; }
      .section-title {
        font-size: 12px; font-weight: 700; color: var(--blue);
        letter-spacing: .8px; text-transform: uppercase;
        margin-bottom: 10px;
        padding-bottom: 8px;
        border-bottom: 1px solid var(--border);
      }
      p { font-size: 13.5px; color: var(--text-mid); margin-bottom: 10px; }
      ul { list-style: disc; padding-left: 18px; margin: 8px 0; display: flex; flex-direction: column; gap: 5px; }
      li { font-size: 13.5px; color: var(--text-mid); }
      strong { color: var(--text); }
      a { color: #7aa3ff; }
      .sep { height: 1px; background: var(--border); margin: 24px 0; }
      .footer { font-size: 11.5px; color: var(--text-muted); border-top: 1px solid var(--border); padding-top: 16px; margin-top: 8px; }
    </style>
    </head>
    <body>
      <h1>Contratto di Licenza</h1>
      <div class="meta">Condizioni generali d'uso — STIGA S.p.A.</div>

      <div class="info-box">ℹ Leggere attentamente le presenti condizioni prima di utilizzare il Sito. L'utilizzo del Sito implica la piena accettazione di quanto indicato di seguito.</div>

      <div class="section">
        <div class="section-title">1. Condizioni generali d'uso</div>
        <p>La società <strong>STIGA S.p.A.</strong>, avente sede in via del Lavoro 6, Castelfranco Veneto (TV), P.IVA 07684381002, email infoline@stiga.com, +39 0423 450 111 ("Società"), è titolare del presente sito ("Sito").</p>
        <p>L'utilizzazione del Sito da parte dell'Utente comporta la piena e incondizionata accettazione delle presenti Condizioni Generali di Uso. La Società si riserva il diritto di modificarle in ogni momento. L'Utente è tenuto a verificarne il contenuto prima di ogni utilizzo.</p>
      </div>

      <div class="section">
        <div class="section-title">2. Contenuti del sito</div>
        <p>Il Sito illustra i prodotti della Società ("Prodotti") e fornisce informazioni sulle loro caratteristiche. Non è prevista alcuna attività di commercio elettronico: l'Utente non può acquistare Prodotti sul Sito, ma può farlo presso i rivenditori autorizzati.</p>
        <p>La Società si riserva il diritto di cambiare, modificare, aggiungere o rimuovere parti del Sito o dei Prodotti in qualsiasi momento.</p>
      </div>

      <div class="section">
        <div class="section-title">3. Proprietà intellettuale</div>
        <p>La Società e/o le altre società del gruppo STIGA sono titolari esclusivi dei marchi "Stiga" e dei relativi nomi di dominio. Tutti i diritti di proprietà intellettuale relativi al Sito — inclusi:</p>
        <ul>
          <li>Contenuti, nomi, dati e informazioni sui Prodotti</li>
          <li>Fotografie, immagini, video, testi e disegni</li>
          <li>Musica, banche dati e software</li>
        </ul>
        <p>sono protetti dalla legge (D.Lgs. 10/02/2005 n. 30 e L. 22/04/1941 n. 633). Nessuna licenza è concessa agli Utenti. È vietato copiare, riprodurre, tradurre, modificare o distribuire l'IP STIGA.</p>
      </div>

      <div class="section">
        <div class="section-title">4. Disclaimer</div>
        <p>La Società non garantisce che le informazioni fornite nel Sito siano esaustive, corrette e aggiornate. L'Utente è tenuto a verificarne personalmente la correttezza.</p>
      </div>

      <div class="section">
        <div class="section-title">5. Informazioni sui rivenditori</div>
        <p>La Società non effettua controlli sulla veridicità dei dati relativi ai rivenditori menzionati nel Sito. L'Utente è tenuto a verificare tali informazioni prima di contattare qualsiasi rivenditore.</p>
      </div>

      <div class="section">
        <div class="section-title">6. Link a siti di terzi</div>
        <p>La Società non garantisce la funzionalità né l'accuratezza dei siti di terze parti eventualmente linkati nel Sito, e non è responsabile di quanto in essi pubblicato.</p>
      </div>

      <div class="sep"></div>

      <div class="section">
        <div class="section-title">7. Dati personali</div>
        <p>Il trattamento dei dati personali è descritto nell'apposita Informativa sulla Privacy, che l'Utente è tenuto a leggere attentamente.</p>
      </div>

      <div class="section">
        <div class="section-title">8. Intero accordo</div>
        <p>Le presenti Condizioni Generali di Uso contengono nella loro interezza gli accordi intervenuti fra le Parti sulla materia che ne è oggetto.</p>
      </div>

      <div class="section">
        <div class="section-title">9. Clausole inefficaci</div>
        <p>Qualora una clausola sia considerata nulla od inefficace, sarà considerata scindibile dalle restanti e non ne pregiudicherà la validità.</p>
      </div>

      <div class="section">
        <div class="section-title">10. Rinuncia all'esercizio di un diritto</div>
        <p>Il mancato o ritardato esercizio da parte della Società di un diritto previsto dalle presenti Condizioni o dalla legge non ne comporta la decadenza.</p>
      </div>

      <div class="section">
        <div class="section-title">11. Legge applicabile — Foro competente</div>
        <p>Le presenti Condizioni sono regolate dalla legge italiana. Il foro esclusivamente competente è il <strong>Foro di Treviso</strong>.</p>
      </div>

      <div class="footer">STIGA S.p.A. — Via del Lavoro 6, 31033 Castelfranco Veneto (TV), Italy</div>
    </body>
    </html>
    """
}
